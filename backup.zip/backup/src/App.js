import './App.css';
import {WorkArea} from './components'

function App() {
  return (
    <div className="App">
      <WorkArea/>
    </div>
  );
}

export default App;
